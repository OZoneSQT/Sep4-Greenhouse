/*
 * FreeRTOSTraceDriver.h
 *
 * Created: 28/02/2019 11:07:33
 *  Author: IHA
 */ 


#ifndef FREERTOSTRACEDRIVER_H_
#define FREERTOSTRACEDRIVER_H_

void trace_init(void);

#endif /* FREERTOSTRACEDRIVER_H_ */