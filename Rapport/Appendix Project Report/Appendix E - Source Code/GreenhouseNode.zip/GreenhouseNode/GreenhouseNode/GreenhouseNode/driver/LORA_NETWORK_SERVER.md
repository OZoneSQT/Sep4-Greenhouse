# LoRaWAN Network Server
In this project we are using a Loriot Network Server.

## Websocket output format
### Overview
![Loriot Output Overview](/docs/documentation/Loriot/Overview.png)

### Uplink Format
![Loriot Output Uplink](/docs/documentation/Loriot/Uplink.png)

### Downlink Format
![Loriot Output Downlink](/docs/documentation/Loriot/Downlink.png)

### Gateway Format
![Loriot Output Gateway](/docs/documentation/Loriot/Gateway.png)
