#pragma once

#include "error.h"

bool sensor_init();
float sensor_read();
