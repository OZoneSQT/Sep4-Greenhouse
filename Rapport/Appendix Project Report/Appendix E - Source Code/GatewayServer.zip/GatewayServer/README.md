# GatewayServer

This is a semester project for VIA University College.
This repo is a part of a bigger project with IoT, Datawarehousing and Android.

This repository is maintained by the Data Engineering team from Group 1.
SCRUM was used for the development and the team was working with pair programming.

API (Swagger Documentation): https://bit.ly/3rEHMsr
